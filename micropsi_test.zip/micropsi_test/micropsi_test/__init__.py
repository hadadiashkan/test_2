"""Top-level package for micropsi_test."""

__author__ = """Ashkan Hadadi"""
__email__ = "hadadi.ashkan@gmail.com"
__version__ = "0.1.0"
