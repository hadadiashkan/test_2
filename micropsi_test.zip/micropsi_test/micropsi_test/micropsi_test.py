from typing import List
Vector = List[float]


def find_min(arr: Vector) -> float:
    """Finds the minimum element of arr using the binary search algorithm."""

    low_index, high_index = 0, (len(arr) - 1)
    # Do a binary search
    while low_index < high_index:

        # find the mid element
        mid_index = (low_index + high_index) // 2

        # Check for break point
        if arr[mid_index] < arr[mid_index + 1]:
            high_index = mid_index
        else:
            low_index = mid_index + 1
        # we can use return here too because of the array nature.
    return arr[low_index]
