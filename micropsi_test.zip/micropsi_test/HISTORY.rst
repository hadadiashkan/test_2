=======
History
=======

0.1.0 (2021-10-11)
------------------

* First release on PyPI.
