=====
Usage
=====

To use micropsi_test in a project::

    import micropsi_test
