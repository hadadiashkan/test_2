=============
micropsi_test
=============


.. image:: https://img.shields.io/pypi/v/micropsi_test.svg
        :target: https://pypi.python.org/pypi/micropsi_test

.. image:: https://img.shields.io/travis/hadadiashkan/micropsi_test.svg
        :target: https://travis-ci.com/hadadiashkan/micropsi_test

.. image:: https://readthedocs.org/projects/micropsi-test/badge/?version=latest
        :target: https://micropsi-test.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/hadadiashkan/micropsi_test/shield.svg
     :target: https://pyup.io/repos/github/hadadiashkan/micropsi_test/
     :alt: Updates



A Python package for calculating the minimum element of an array


* Free software: MIT license
* Documentation: https://micropsi-test.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
