#!/usr/bin/env python

"""Tests for `micropsi_test` package."""

import pytest

from click.testing import CliRunner

from micropsi_test import micropsi_test
from micropsi_test import cli
from micropsi_test.micropsi_test import find_min


@pytest.mark.parametrize(
    "array, expected_minimum",
    [([8, 5, 4, 3, 4, 10], 3), ([12, 11, 10, 9, 5, 5, 7, 9, 15, 20], 5)],
)
def test_find_minimum_element(array, expected_minimum):
    minimum_element = find_min(array)
    assert minimum_element == expected_minimum


def test_command_line_interface():
    """Test the CLI."""
    runner = CliRunner()
    result = runner.invoke(cli.main)
    assert result.exit_code == 0
    assert "micropsi_test.cli.main" in result.output
    help_result = runner.invoke(cli.main, ["--help"])
    assert help_result.exit_code == 0
    assert "--help  Show this message and exit." in help_result.output
